package mx.tecnm.tepic.ladm_u1_practica2

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.RadioButton
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var radioButtonSeleccionado =""
        radioGroup.setOnCheckedChangeListener{ d, i->
            var R : RadioButton = findViewById(i)               //Devuelve Radio Button Seleccionado
            radioButtonSeleccionado = R.text.toString()+""
        }

        btnGuardar.setOnClickListener {
            var seleccion : Int = radioGroup.checkedRadioButtonId
            if(noEstaSeleccionado(seleccion)){

                mensaje("Almacenamiento No Seleccionado")

            }else{
                if(radioButtonSeleccionado.equals("Archivo Memoria INTERNA")){
                    guardarArchivoInterno()
                }else{
                    if(ContextCompat.checkSelfPermission(this,                      //Guarda Archivo en almacenamiento seleccionado
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)==
                            PackageManager.PERMISSION_DENIED){
                        ActivityCompat.requestPermissions(this,
                            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE),0)
                    }else{

                    }
                    guardarArchivosSD()
                }
            }
        }

        btnLeer.setOnClickListener {
            var seleccion : Int = radioGroup.checkedRadioButtonId
            if(noEstaSeleccionado(seleccion)){

                mensaje("Almacenamiento No Seleccionado")
                                                                                            //Lee archivo del almacenamiento seleccionado
            }else{
                if(radioButtonSeleccionado.equals("Archivo Memoria INTERNA")){
                    leerArchivoInterno()
                }else{
                    if(ContextCompat.checkSelfPermission(this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)==
                            PackageManager.PERMISSION_DENIED){
                        ActivityCompat.requestPermissions(this,
                            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE),0)
                    }else{

                    }

                    leerArchivoSD()
                }
            }
        }
    }


    fun guardarArchivoInterno(){
        var nombre = txtNombreArchivo.text.toString()
        try {
            var flujoSalida =
                OutputStreamWriter(openFileOutput(nombre+".txt", Context.MODE_PRIVATE))
            var data = txtFrase.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()                                                                     //Guarda archivo en Almacenamiento interno
            flujoSalida.close()
            mensaje("Archivo Guardado Correctamente :)")
            txtFrase.setText("")
            txtNombreArchivo.setText("")
        }catch (error:IOException){
            mensaje(error.message.toString())
        }
    }


    private fun leerArchivoInterno(){
        var nombre = txtNombreArchivo.text.toString()
        try {
            var flujoEntrada = BufferedReader(InputStreamReader(openFileInput(nombre+".txt")))
            var data = flujoEntrada.readLine()
            var vector = data.split("&")                                     //Lee archivo en almacenamiento interno
            ponerTexto(vector[0])
            flujoEntrada.close()
        }catch (error:IOException){

        }
    }


    fun mensaje(m:String){
        AlertDialog.Builder(this)
            .setTitle("AVISO")
            .setMessage(m)
            .setPositiveButton("Aceptar"){d, i->}
            .show()
    }


    fun ponerTexto(t1:String){
        txtFrase.setText(t1)
    }


    fun noEstaSeleccionado(x : Int):Boolean{

        if(x==-1){
            return true
        }
        return false

    }


    fun nosSD():Boolean{
        var estado = Environment.getExternalStorageState()
        if(estado != Environment.MEDIA_MOUNTED){
            return true

        }

        return false
    }


    fun leerArchivoSD(){

        if(nosSD()){
            mensaje("NO HAY MEMORIA EXTERNA INSERTADA :(")
            return
        }

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivos = File(rutaSD.absolutePath, txtNombreArchivo.text.toString()+".txt" )

            var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosArchivos)))
            var data = flujoEntrada.readLine()
            var vector = data.split("&")
            ponerTexto(vector[0])
            flujoEntrada.close()

        }catch (error : IOException){

        }
    }


    fun guardarArchivosSD(){

        if(nosSD()){

            mensaje("NO HAY MEMORIA EXTERNA INSERTADA :(")
            return
        }

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivo = File(rutaSD.absolutePath,txtNombreArchivo.text.toString()+".txt")

            var flujoSalida = OutputStreamWriter(FileOutputStream(datosArchivo))
            var data = txtFrase.text.toString()
            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()
            mensaje("Achivo Guardado Correctamente :)")
            txtFrase.setText("")
            txtNombreArchivo.setText("")
        }catch ( error :IOException){
            mensaje(error.message.toString())
        }
    }






}